

    // Get the button element
    var btn = document.getElementById("bg");

    // Add click event listener to the button
    btn.addEventListener("click", function() {
        // Redirect to home.html
        window.location.href = "home.html";
    });

